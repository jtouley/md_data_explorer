function model = load_sepsis_model()
    model = load('Model.mat');
end
