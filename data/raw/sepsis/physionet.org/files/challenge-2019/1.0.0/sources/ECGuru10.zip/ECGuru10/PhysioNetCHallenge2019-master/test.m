clc;clear all;close all;
driver('../training_original2_part','../res_tmp')