# Instructions

The Python script `driver.py` makes predictions on the input data.

To run this script, install dependencies and required python packages and run

        python driver.py input_folder output_folder

which takes `input_folder` (a folder containing psv  files) as input and writes prediction results to the `output_folder`.
