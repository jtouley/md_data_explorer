# challenge2019

## Usage

`python driver.py input_directory/ output_directory/`

where input_directory is a directory for input data files and output_directory is a directory for output prediction files. The PhysioNet/CinC 2019 webpage provides a training database with data files and a description of the contents and structure of these files.

## Details

See the PhysioNet/CinC 2019 webpage for more details, including instructions for the other files in this repository.