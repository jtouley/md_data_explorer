Tzvi Aviv
Example prediction code for R for the PhysioNet/CinC Challenge 2019

modified scripts for:
1. training an xgboost model on setA plus setB of sepsis data
2. get_spesis_score.R modified to load the xgboost model and predict sepsis scores
3. Dockerize - install xgboost 


